#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <errno.h>

#define uchar unsigned char
#define N 255

typedef struct {
    int ready;
    char buf[N];
} shmbuf;

void main() {
    int shmid;
    void *shm = NULL;
    shmbuf *share;
    char buf[255];
    uchar runing=1;

    shmid = shmget((key_t)1024, sizeof(shmbuf), 0666 | IPC_CREAT);
    if (shmid < 0) {
        printf("get shmid wrong!\n");
        exit(EXIT_FAILURE);
    }
    shm = shmat(shmid, 0, 0);
    if (shm < (void *)0) {
        printf("attach share memery error!\n");
        exit(EXIT_FAILURE);
    }

    printf("\nMemory attached at %X\n", (int)shm);

    share = (struct myshm *)shm;

    while(runing) {
        while(share->ready==0) {
            // printf("Waiting reader...\n");
            sleep(1);
        }
        printf("Please input some thing you want to transfer to reader:");
        fgets(buf,255,stdin);
        if(strncmp(buf,"quit",4)==0) runing=0;
        strncpy(share->buf,buf,255);
        share->ready=0;

    }
    if(shmdt(shm)<0) {
        printf("Deatch from share memory wrong!\n");
        exit(EXIT_FAILURE);
    }
    sleep(1);
    exit(EXIT_SUCCESS);
}