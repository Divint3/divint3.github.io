#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <errno.h>
#include <unistd.h>

#define uchar unsigned char
#define N 255
typedef struct {
    int ready;
    char buf[N];
} shmbuf;

int fact(int);

void main() {
    int shmid,len;
    void *shm = NULL;
    shmbuf *share;
    uchar runing=1;

    shmid = shmget((key_t)1024, sizeof(shmbuf), 0666 | IPC_CREAT);
    if (shmid < 0) {
        printf("get shmid wrong!\n");
        exit(EXIT_FAILURE);
    }
    shm = shmat(shmid, 0, 0);
    if (shm < (void *)0) {
        printf("attach share memery error!\n");
        exit(EXIT_FAILURE);
    }

    printf("\nMemory attached at %X\n", (int)shm);
    share = (struct myshm *)shm;
    share->ready = 1;
    while(runing) {
        while(share->ready==1) {
            // printf("Waiting writer...\n");
            sleep(1);
        }
        if(strncmp(share->buf,"quit",4)==0) runing=0;

        len=strlen(share->buf)-1;
        if(len==0) {
            printf("You have not get any thing!\n");
            share->ready=1;
            continue;
        }


        char temp[len];
        memset(temp,'\0',len);
        strncpy(temp,share->buf,len);
        if(strspn(temp, "0123456789") != len) {
            printf("You input NaN!\n");
        } else if(atoi(temp)<33) {
            printf("You got %d!:%lld\n",atoi(temp),fact(atoi(temp)));
        } else {
            printf("Your input is too huge~!\n");
        }
        share->ready=1;

    }
    if(shmdt(shm)<0) {
        printf("Deatch from share memory error!\n");
        exit(EXIT_FAILURE);
    }
    if(shmctl(shmid,IPC_RMID,0)<0) {
        printf("Delete share memory error!\n");
        exit(EXIT_FAILURE);

    }
    sleep(1);
    exit(EXIT_SUCCESS);
}


int fact(int n) {
    if(n==1) return 1;
    else return n*fact(n-1);
}