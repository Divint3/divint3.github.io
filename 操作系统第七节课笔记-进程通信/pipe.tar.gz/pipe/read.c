#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#define FIFO_FILE "/tmp/fifo"
#define DATA_FILE "./hw_4"

#define uint unsigned int
#define uchar unsigned char


void main(){
    int fd;
    FILE *data;
    char buf[255];
    uint data_len=0;
    uint times=0;
    char *needle;


    data=fopen(DATA_FILE,"r+");
    fseek(data,0,SEEK_END); //跳到文件末尾
    data_len= ftell(data); //的到文件长度
    rewind(data);
    char pBuf[data_len+1]; //创建等长缓冲区
    fread(pBuf,1,data_len,data);

    fclose(data); //关闭数据文件
    fd=open(FIFO_FILE,O_RDONLY);
    printf("pipe get connected!\n");
    
    while(1){
        memset(buf,'\0',sizeof(buf));
        times=0;
        needle=pBuf;
        read(fd,buf,sizeof(buf));   
        if(strncmp(buf,":q",2)==0) break;
        while(1){
            needle=strstr(needle,buf);
            if(needle==NULL) break;

            needle=needle+strlen(buf);
            times+=1;
        };
        if(times!=0){
            printf("%s:%d\n",buf,times);
        }else{
            printf("%s not found\n",buf);
        }
        
    };
    close(fd);  //关闭文件尾
    printf("bye!\n");

}