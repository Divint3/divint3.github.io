#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FIFO_FILE "/tmp/fifo"

void main(){
    int fd;
    char buf[255];
    unlink(FIFO_FILE);
    if(mkfifo(FIFO_FILE,0777)<0) return;
    
    fd=open(FIFO_FILE,O_WRONLY);
    printf("pipe get connected!\n");
    do{
        memset(buf,'\0',255);
        printf("Some thing input:");
        gets(buf);
        
        write(fd,buf,sizeof(buf));
    }while(strncmp(buf,":q",2)!=0);

    printf("bye!\n");
    close(fd);
    
} 